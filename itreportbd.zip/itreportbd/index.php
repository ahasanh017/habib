<?php
include("include/header.php");
include("include/home_slider.php");
?>
				<div class="content_area">
					<div class="main_content floatleft">
						<div class="left_coloum floatleft">
						
							<div class="single_left_coloum_wrapper">
								<h2 class="title">এক্সক্লুসিভ</h2>
								<a class="more">more</a>
								<?php include("include/db_connect.php");
							
								$result = mysql_query("SELECT * FROM news where catagori=1 ORDER BY id DESC LIMIT 3");
								while( $row = mysql_fetch_array($result) )
								{ ?>
								<div class="single_left_coloum floatleft">
									<img src="admin/<?php echo $row['image'].""; ?>" alt="" id="im"/>
									<h3><?php echo $row['headline'].""; ?></h3>
									<p><?php echo $row['short_news'].""; ?></p>
									<form action="single_news.php?id=<?php echo $row['id']."";?>" method="post" style="display:inline;">
					<input type="hidden" value="<?php echo $row['id'];?>" name="id">
					<button type="submit" class="btn btn-default btn-xs"  id="delate" name="delate">
									<a class="read more...">বিস্তারিত</a>
									</button>
					</form>
								</div>
								<?php
								}
								mysql_close($con);
							?>
							</div>
							
							<div class="single_left_coloum_wrapper">
								<h2 class="title">বিডি আইটি</h2>
								<a class="more">more</a>
								<?php include("include/db_connect.php");
								$result = mysql_query("SELECT * FROM news where catagori=2 ORDER BY id DESC LIMIT 3");
								while( $row = mysql_fetch_array($result) )
								{ ?>
								<div class="single_left_coloum floatleft">
									<img src="admin/<?php echo $row['image'].""; ?>" alt="" id="im"/>
									<h3><?php echo $row['headline'].""; ?></h3>
									<p><?php echo $row['short_news'].""; ?></p>
									<form action="single_news.php?id=<?php echo $row['id']."";?>" method="post" style="display:inline;">
								<input type="hidden" value="<?php echo $row['id'];?>" name="id">
								<button type="submit" class="btn btn-default btn-xs"  id="delate" name="delate">
									<a class="read more...">বিস্তারিত</a>
								</button>
								</form>
								</div>
								<?php
								}
								mysql_close($con);
							?>
							</div>
							<div class="single_left_coloum_wrapper">
								<h2 class="title">ওয়ার্ল্ড আইটি</h2>
								<a class="more">more</a>
								<?php include("include/db_connect.php");
								
								$result = mysql_query("SELECT * FROM news where catagori=3 ORDER BY id DESC LIMIT 3");
								while( $row = mysql_fetch_array($result) )
								{ ?>
								<div class="single_left_coloum floatleft">
									<img src="admin/<?php echo $row['image'].""; ?>" alt="" id="im"/>
									<h3><?php echo $row['headline']."";?></h3>
									<p><?php echo $row['short_news']."";?></p>
									<form action="single_news.php?id=<?php echo $row['id']."";?>" method="post" style="display:inline;">
								<input type="hidden" value="<?php echo $row['id'];?>" name="id">
								<button type="submit" class="btn btn-default btn-xs"  id="delate" name="delate">
									<a class="read more...">বিস্তারিত</a>
								</button>
								</form>
								</div>
								<?php
								}
								mysql_close($con);
							?>
							</div>
							<div class="single_left_coloum_wrapper gallery">
								<h2 class="title">গেলারী</h2>
								<a class="more">more</a>
								<?php include("include/db_connect.php");
								
								$result = mysql_query("SELECT * FROM news ORDER BY id DESC LIMIT 3");
								while( $row = mysql_fetch_array($result) )
								{ ?>
								<div class="single_left_coloum floatleft">
									<form action="single_news.php?id=<?php echo $row['id']."";?>" method="post" style="display:inline;">
								<input type="hidden" value="<?php echo $row['id'];?>" name="id">
									<a href="single_news.php?id=<?php echo $row['id'];?>"><img src="admin/<?php echo $row['image'].""; ?>" alt="" id="im"/></a>
								</form>

								</div>
								<?php
								}
								mysql_close($con);
							?>
								
							</div>
							<div class="single_left_coloum_wrapper single_cat_left">
								<h2 class="title">হোস্টিং</h2>
								<a class="more">more</a>
								<?php include("include/db_connect.php");
								
								$result = mysql_query("SELECT * FROM news where catagori=8 ORDER BY id DESC LIMIT 3");
								while( $row = mysql_fetch_array($result) )
								{ ?>
								<div class="single_left_coloum floatleft">
									<form action="single_news.php?id=<?php echo $row['id']."";?>" method="post" style="display:inline;">
								<input type="hidden" value="<?php echo $row['id'];?>" name="id">
									<a href="single_news.php?id=<?php echo $row['id'];?>">
									<h3><b><?php echo $row['headline'].""; ?></b></h3>
									<p><?php echo $row['short_news'].""; ?></p>
									</a>
								</form>
									
									
								</div>
								<?php
								}
								mysql_close($con);
							?>
		
							</div>
						</div>
						<div class="right_coloum floatright">
							<div class="single_right_coloum">
								<h2 class="title">আপডেট</h2>
								
								<ul>
								<?php include("include/db_connect.php");
								
								$result = mysql_query("SELECT * FROM news ORDER BY ID DESC LIMIT 3");
								while( $row = mysql_fetch_array($result) )
								{ ?>
									<li>
										<div class="single_cat_right_content">
											<h3><?php echo $row['headline'].""; ?></h3>
											<p><?php echo $row['short_news'].""; ?></p>
											<p class="single_cat_right_content_meta">
								<form action="single_news.php?id=<?php echo $row['id']."";?>" method="post" style="display:inline;">
								<input type="hidden" value="<?php echo $row['id'];?>" name="id">
								<button type="submit" class="btn btn-default btn-xs"  id="delate" name="delate">
									<a class="read more...">বিস্তারিত</a>
								</button>
								</form>
										</div>
									</li>
									
									<?php
								}
								mysql_close($con);
							?>
								</ul>
							
							</div>
							<div class="single_right_coloum">
								<h2 class="title">নির্বাচিত</h2>
								<?php include("include/db_connect.php");
								
								$result = mysql_query("SELECT * FROM news ORDER BY ID DESC LIMIT 4,7");
								while( $row = mysql_fetch_array($result) )
								{ ?>
								<div class="single_cat_right_content editorial">
								<form action="single_news.php?id=<?php echo $row['id']."";?>" method="post" style="display:inline;">
								<input type="hidden" value="<?php echo $row['id'];?>" name="id">
								<button type="submit" class="btn-default"  id="delate" name="delate">
								
									<img src="admin/<?php echo $row['image'].""; ?>" alt=""/>
									<h3><?php echo $row['headline'].""; ?></h3>
									</button>
									</form>
								</div>
								
								<?php
								}
								mysql_close($con);
							?>
							
							</div>
						</div>
					</div>
					<div class="sidebar floatright">
						<div class="single_sidebar">
							<img src="images/add1.png" alt=""/>
						</div>
						<div class="single_sidebar">
							<div class="news-letter">
								<h2>Subscribe   Newsletter</h2>
								<p>Subscribe to receive our free newsletters!</p>
								<form>
									<input type="text" value="Name" id="name"/>
									<input type="text" value="Email Address" id="email"/>
									<input type="submit" value="Subscribe" id="form-submit"/>
								</form>
								<p class="news-letter-privacy">We do not spam. We value your privacy!</p>
							</div>
						</div>
						<div class="single_sidebar">
							<div class="popular" id="sidee">
								<h2 class="title">জনপ্রিয়</h2>
								
								<ul>
								<?php include("include/db_connect.php");
								
								$result = mysql_query("SELECT * FROM news ORDER BY id DESC LIMIT 8,13");
								while( $row = mysql_fetch_array($result) )
								{ ?>
									<li>
									<div class="single_popular">
									<a href="single_news.php?id=<?php echo $row['id'];?>">
									<b align="left"><?php echo $row['headline'].""; ?></b>
									</a>
							</form>
										</div>
									</li>
									<?php
								}
								mysql_close($con);
							?>
								</ul>
							</div>
						</div>
						<div class="single_sidebar">
							<img src="images/add1.png"/>
						</div>						
						<div class="single_sidebar">
							<h2 class="title">ADD</h2>
							<img src="images/add2.png" alt=""/>
						</div>
					</div>
				</div>
				<div class="footer_top_area">
					<div class="inner_footer_top">
						<img src="images/worlditexpert.png" alt="" width="100%" height="100%"/>
					</div>
				</div>
				
	<?php 
	include("include/footer_bottom.php");
	include("include/footer.php");
?>	