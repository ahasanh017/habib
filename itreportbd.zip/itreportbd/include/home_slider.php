<div class="slider_area">
					<div class="slider">
						
						<ul class="bxslider">
						<?php include("include/db_connect.php");
							
								$result = mysql_query("SELECT * FROM slider ORDER BY id DESC LIMIT 10");
								while( $row = mysql_fetch_array($result) )
								
								{ ?>
						  <li><img src="admin/<?php echo $row['image']."";?>" title="Funky roots" height="20%" width="100%"/></li>
						  
						  <?php
								}
								mysql_close($con);
							?>
						</ul>
						
					</div>
				</div>