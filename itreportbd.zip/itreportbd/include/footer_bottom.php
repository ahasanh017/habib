<div class="footer_bottom_area">
					<div class="footer_menu">
						<ul id="f_menu">
							<li><a href="index.php">নীড় পাতা</a></li>
							<li><a href="exclusive.php">এক্সক্লুসিভ</a></li>
							<li><a href="bdit.php">বিডি আইটি</a></li>
							<li><a href="worldit.php">ওয়ার্ল্ড আইটি</a></li>
							<li><a href="binodon.php">বিনোদন</a></li>
							<li><a href="mobile.php">মোবাইল</a></li>
							<li><a href="computer.php">কম্পিউটার</a></li>
							<li><a href="domain.php">ডোমেইন</a></li>
							<li><a href="hosting.php">হোস্টিং</a></li>
							<li><a href="live_even.php">লাইভ ইভেন</a></li>
						</ul>
					</div>
					<div class="copyright_text">
						<p>Copyright MD. <a href="ahasanh017@gmail.com">Ahasan Habib</a><br/>
							
						</p>
					</div>
				</div>