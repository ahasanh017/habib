﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<!--

	News-Reporter responsive template by Whatevercodes
	http://www.whatevercodes.com | Alin
	Free for personal and commercial use under the GNU General Public License (whatevercodes.com/license).
	
	You are not permitted to upload this template directly in your site for download.
	But you can refer people's to download this template from http://www.whatevercodes.com

-->
	<head>
		<title>It Report BD</title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
		<!-- Font Awesome -->
		<link rel ="shortcut icon" type ="text/css" href="images/it.gif"/>
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="font/bebas/stylesheet.css">
		<link href="style.css" rel="stylesheet" media="screen">	
		<link href="responsive.css" rel="stylesheet" media="screen">		
		<link href="css/jquery.bxslider.css" rel="stylesheet" media="screen">		
	</head>

	<body>
		
		<div class="body_wrapper">
			<div class="center">
				<div class="header_area">
					<div class="logo floatleft">
						<a href="#"> <img src="images/logoit.png" alt="logo"  height="50" width="250"/> </a>
					</div>
					<div class="top_menu floatleft">
						<ul>
						
							<li><a href="">Contact us</a></li>
							<li><a href="">Subscribe</a></li>
							<li><a href="">Login</a></li>
						</ul>
					</div>
					<div class="social_plus_search floatright">
						<div class="social">
							<ul>
								<li><a href="" class="twitter"></a></li>
								<li><a href="" class="facebook"></a></li>
								<li><a href="" class="feed"></a></li>
							</ul>
						</div>
						<div class="search">
							<form id="search_form">
								<input type="text" value="Search news" id="s"/>
								<input type="submit" id="searchform" value="search"/>
								<input type="hidden" value="post" name="post_type"/>
							</form>
						</div>
					</div>
				</div>
				<div class="main_menu_area">
					<ul id="nav">
						<li><a href="index.php">নীড় পাতা</a></li>
						<li><a href="exclusive.php">এক্সক্লুসিভ</a></li>
						<li><a href="bdit.php">বিডি আইটি</a></li>
						<li><a href="worldit.php">ওয়ার্ল্ড আইটি</a></li>
						<li><a href="binodon.php">বিনোদন</a></li>
						<li><a href="mobile.php">মোবাইল</a></li>
						<li><a href="computer.php">কম্পিউটার</a></li>
						<li><a href="domain.php">ডোমেইন</a></li>
						<li><a href="hosting.php">হোস্টিং</a></li>
						<li><a href="live_even.php">লাইভ ইভেন</a></li>
					</ul>
				</div>