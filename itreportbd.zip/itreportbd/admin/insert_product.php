<?php
include("include/header.php");
?>
<div class="col-md-8">
<font color="yellow">
<form action="insert_process.php" method="post"
		enctype="multipart/form-data">
		</br>
		</br>
		<label>Select Menu</label>
			<select class="form form-control" name="catagori">
				<option class="form form-control" name="" value="">Select One</option>
				<option class="form form-control" value="1">ক্সক্লুসিভ</option>
				<option class="form form-control" value="2">বিডি আইটি</option>
				<option class="form form-control" value="3">ওয়ার্ল্ড আইটি</option>
				<option class="form form-control" value="4">বিনোদন</option>
				<option class="form form-control" value="5">মোবাইল</option>
				<option class="form form-control" value="6">কম্পিউটার</option>
				<option class="form form-control" value="7">ডোমেইন</option>
				<option class="form form-control" value="8">হোস্টিং</option>
				<option class="form form-control" value="9">লাইভ ইভেন</option>
			</select>
		</br>
		<label>Head_Line</label>
		<input type="text" name="headline" class="form-control" required></br>
		<label for="file">Image:</label>
		<input type="file" name="file" id="file" /> 
		<br />
		<label>Short News</label>
		<textarea class="form-control" name="short" rows="3" required></textarea></br>
		<label>Full News</label>
		<textarea class="form-control" name="full" rows="6" required></textarea></br>
		
		<input type="submit" class="btn btn-primary" value="Submit">

</form>
</font>
</div>

<?php
include("include/footer.php");
?>