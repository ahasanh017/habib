<?php include("include/header.php"); ?>
<div class="col-md-8">
<center></br></br></br></br></br></br><h1><span class="btn-default">***Welcome To Confidence Furniture***</span></h1>
<h1><span class="btn-default">Admin Panel</span></h1></center>
</div>
<?php include("include/footer.php"); ?>