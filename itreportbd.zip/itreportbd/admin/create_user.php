<?php include("include/header.php"); ?>
		
		<div class="col-md-8">
		</br>
		<font color="yellow">
		<h3>Create New User</h3>
		<form action="user.php" method="post"
		enctype="multipart/form-data">

		<label>First Name</label>
		<input type="text" name="fname" class="form-control" required></br>
		 <label>Last Name</label>
		<input type="text" name="lname" class="form-control" required>
		<br />
		<label>User Name</label>
		<input type="text" name="uname" class="form-control" required></br>
		<label>Password</label>
		<input type="text" name="password" class="form-control" required></br>
		<label>Email</label>
		<input type="email" name="email" class="form-control" required></br>
		<input type="submit" class="btn btn-primary" value="Submit">

</form>
</font>
</div>
	<?php include("include/footer.php"); ?>