<?php
session_start();
$user_id=$_SESSION['id'];
$user_status=$_SESSION['uname'];
$user_msg=$_SESSION['logged_msg'];
$i=1;

if($user_id==$i<100)

{
?>
<?php   
include("include/db_connect.php");
 ?>
	<?php

		$eid=$_POST['id'];
		
        $query = "DELETE FROM slider WHERE id=$eid ";

        $result = mysql_query($query,$con);
		if($result){
	echo"<center><h3><font color=green>Product Delate Successfully!</font></h3></center>";
		include("insert_slider.php");
}
}
?>	