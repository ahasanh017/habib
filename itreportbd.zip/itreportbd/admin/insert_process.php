

<?php
if (((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg"))
|| ($_FILES["file"]["type"] == "image/pjpeg"))
|| ($_FILES["file"]["type"] == "image/png"))

  {
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
  else
    {
	
    //echo "Upload: " . $_FILES["file"]["name"] . "<br />";
  // echo "Type: " . $_FILES["file"]["type"] . "<br />";
   // echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";    
		if (file_exists("upload/" . $_FILES["file"]["name"]))
      {
      echo $_FILES["file"]["name"] . " already exists. ";
      }
    else
      {
	  
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "upload/" . $_FILES["file"]["name"]);
      //echo "Stored in: " . "upload/" . $_FILES["file"]["name"];
	  
	  
	  
	  //$image_name = $random . $file_type;
	  $image_name = "upload/" . $_FILES["file"]["name"];
		
		include("include/db_connect.php");

$catagori=$_POST["catagori"];
$headline=$_POST["headline"];
$short_news=$_POST["short"];
$full_news=$_POST["full"];


$sql=mysql_query("Insert into `publish_news`.`news` 
			(`catagori`,`headline`,`short_news`,`full_news`,`image`) values
			('".$catagori."','".$headline."','".$short_news."','".$full_news."','".$image_name."')");			
	if(isset($sql)){
		echo "<font color=red><center><h1> Your Data Inserted Successfully</h1></center></font>";
		include("insert_product.php");
	}
      }
    }
  }
else
  {
  echo "Invalid file";
  }
?>


