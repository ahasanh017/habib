<?php
if (((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg"))
|| ($_FILES["file"]["type"] == "image/pjpeg"))
|| ($_FILES["file"]["type"] == "image/png"))

  {
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
  else
    {
	
    //echo "Upload: " . $_FILES["file"]["name"] . "<br />";
  // echo "Type: " . $_FILES["file"]["type"] . "<br />";
   // echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";    
		if (file_exists("slider/" . $_FILES["file"]["name"]))
      {
      echo $_FILES["file"]["name"] . " already exists. ";
      }
    else
      {
	  
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "slider/" . $_FILES["file"]["name"]);
      //echo "Stored in: " . "upload/" . $_FILES["file"]["name"];
	  
	  
	  
	  //$image_name = $random . $file_type;
	  $image_name = "slider/" . $_FILES["file"]["name"];
	  
	  include("include/db_connect.php");
$sql=mysql_query("Insert into `publish_news`.`slider` 
			(`image`) values
			('".$image_name."')");			
	if(isset($sql)){
		echo "<font color=red><center><h1> Your Data Inserted Successfully</h1></center></font>";
		include("insert_slider.php");
	}
	  }
    }
  }
else
  {
  echo "Invalid file";
  }
?>