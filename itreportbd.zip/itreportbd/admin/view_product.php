<?php
include("include/header.php");
?>
<div class="col-md-8" id="im">
							
								<font color="yellow"><h2>View All Product </h2>
								<hr class="hr alert-danger"/>
							
							<div class="row" id="im">
<?php 
include("include/db_connect.php");
$result = mysql_query("SELECT * FROM products ORDER BY id DESC");
	while( $row = mysql_fetch_array($result) )
                {
				?>
							  <div class="col-sm-6 col-md-3 text-center" id="im">
						
							    <div class="img-responsive" id="im">
							      <img src="<?php echo $row['pimage'].""; ?>" alt="..." height="150" width="180" id="im">
							      <div class="caption">
							        <h3 name="id"><?php echo $row['pname'].""; ?></h3>
							        
							        <hr class="hr"/>
									<p><form action="delate_product.php" method="post" style="display:inline;" onsubmit="if(confirm('delete? Are you sure?')){return true} else{return false};">
									<input type="hidden" value="<?php echo $row['id']."";?>" name="id">
									<button type="submit" class="btn btn-danger"  id="delate" name="delate">Delete</button>
									</form>
				
									
									
									<a href="edit.php" class="btn btn-default" role="button">Edit</a></p>
							    
								  </div>
							    </div>
							
		
								
							  </div>
							 <?php
				}
				mysql_close($con);
				?>
				</div>
				</font>
				</div>
							

<?php
include("include/footer.php");
?>