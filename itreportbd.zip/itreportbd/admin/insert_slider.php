<?php
include("include/header.php");
?>

<div class="col-md-3">

<form action="slider_process.php" method="post"
		enctype="multipart/form-data">
		</br>
		</br>
		<font color="red"><p>Image Size Must Be <b>980*250</a> pixel Or Yet Slider Does Not Work Properly</p></font>
		<font color="yellow">
		<label for="file">Select Slider Image:</label>
		<input type="file" name="file" id="file" /> 
		</font>
		<br />
		<input type="submit" class="btn btn-primary" value="Submit">

</form>
</div>
<div class="col-md-5">
<?php include("include/db_connect.php");
							
								$result = mysql_query("SELECT * FROM slider ORDER BY id DESC LIMIT 10");
								while( $row = mysql_fetch_array($result) )
								
								{ ?>
		</br>
		</br>
		<label for="file"></label>
		
		<img src="<?php echo $row['image']."";?>" height="30%" width="100%"/> 
		<br />
		<form action="delate_Slider.php" method="post" style="display:inline;" onsubmit="if(confirm('delete? Are you sure?')){return true} else{return false};">
									<input type="hidden" value="<?php echo $row['id']."";?>" name="id">
									<button type="submit" class="btn btn-danger"  id="delate" name="delate">Delete</button>
									</form>
</font>
<?php
								}
								mysql_close($con);
							?>
</div>

<?php
include("include/footer.php");
?>