<?php
session_start();
$empty_msg=@$_SESSION['empty_msg'];
$unlogged_msg=@$_SESSION['unlogged_msg'];
$error_msg=@$_SESSION['error_msg'];
$logout_msg=@$_SESSION['logout_msg'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Login Form</title>
		<style type="text/css">
			body{
				background-image:url(images/texture.jpg);
			}
		</style>
	</head>

	<body style="font-family:Verdana, Geneva, sans-serif;  font-size:14px;margin:0px;">
		<form name="login" action="login_process.php" method="post">
			<table width="70%" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#FFF;">
				<tr>
					<td colspan="3" height="150" bgcolor="#000000" align="center">
						<span style="margin:0px; padding:0px; font-family:'Times New Roman', Times, serif; font-size:36px; font-weight:800; color:#CCC;">CONFIDENCE FURNITURE</span>
					</td>
				</tr>
				<tr>
					<td width="30%" height="50" align="right" valign="middle" style="padding-right:20px;"><strong>User Name</strong></td>
					<td width="4%" align="center" valign="middle"><strong>:</strong></td>
					<td width="36%" align="left" valign="middle"><input type="text" name="uname" id="uname" style="width:150px;" /></td>
				</tr>
				<tr>
					<td width="30%" align="right" valign="middle" style="padding-right:20px;"><strong>Password</strong></td>
					<td width="4%" align="center" valign="middle"><strong>:</strong></td>
					<td width="36%" align="left" valign="middle"><input type="password" name="password" id="password" style="width:150px;" /></td>
				</tr>
				<tr>
					<td width="70%" height="30" colspan="3" align="center" valign="middle" style="color:#F00; font-size:14px; font-weight:800; text-decoration:blink;">
						<?php
							if($empty_msg)
							{
								echo $empty_msg;
								$_SESSION['empty_msg']="";
							}
							else if($unlogged_msg)
							{
								echo $unlogged_msg;
								$_SESSION['unlogged_msg']="";
							}
							else if($error_msg)
							{
								echo $error_msg;
								$_SESSION['error_msg']="";
							}
							else if($logout_msg)
							{
								echo $logout_msg;
								$_SESSION['logout_msg']="";
							}
							else
							{
								echo "&nbsp;";
							}
						?>
					</td>
				</tr>
				<tr>
					<td colspan="3" align="center" valign="middle" height="50">
						<input type="reset" name="reset" id="reset" value="Reset" />
						<input type="submit" name="submit" id="submit" value="Submit" />
					</td>
				</tr>
				<tr>
					<td colspan="3" width="70%" height="45" bgcolor="#000000" align="right" valign="middle"><span style="margin:0px; padding-right:30px; color:#F00;"><a href="forgot_user_pass.php" style="text-decoration:none; color:#F00; padding-left:40px;"><strong>Forgot your User Name And password ?</strong></a></span></td>
				</tr>
			</table>
		</form>
	</body>
</html>