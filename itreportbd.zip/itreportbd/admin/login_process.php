<?php
extract($_POST);
session_start();

if($uname!="" and $password!="")
{
include("include/db_connect.php");
$sqllog=mysql_query("select * from user where uname='$uname' and password='$password'");

	if($datalog=mysql_fetch_array($sqllog))
	{
		
		$_SESSION['id']=$datalog['id'];
		$_SESSION['uname']=$datalog['uname'];
		
		
		$_SESSION['logged_msg']="Hi"." ".$datalog['fname']." ".$datalog['lname']."!";
		header("Location:home.php");
	}
	else
	{
		
		$_SESSION['unlogged_msg']="Your User Name and Password are not Registered.";
		header("Location:index.php");
	}
}
else
{		
	$_SESSION['empty_msg']="Please Don't Leave Your User Name and Password.";
	header("Location:index.php");
}
?>
