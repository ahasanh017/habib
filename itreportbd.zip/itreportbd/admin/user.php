<?php
session_start();
$user_id=$_SESSION['id'];
$user_status=$_SESSION['uname'];
$user_msg=$_SESSION['logged_msg'];
$i=1;

if($user_id==$i<100)

{
?>
<?php 

include("include/db_connect.php");
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$uname=$_POST["uname"];
$password=$_POST["password"];
$email=$_POST["email"];

$sql=mysql_query("Insert into `confidence`.`user` 
			(`fname`,`lname`,`uname`,`password`,`email`) values
			('".$fname."','".$lname."','".$uname."','".$password."','".$email."')");			
	if(isset($sql)){
		echo "<h1> Your Data Inserted Successfully</h1>";
		include("create_user.php");
	}
      

?>
<?php
}
else
{
	$_SESSION['error_msg']="You are not Registered.<br>Please Contact With Administrator";
	header("Location:index.php");
}
?>