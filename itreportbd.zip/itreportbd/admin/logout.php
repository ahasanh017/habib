<?php
session_start();
		$_SESSION['id']="";
		$_SESSION['category']="";
		$_SESSION['status']="";
		$_SESSION['logged_msg']="";
		
		$_SESSION['logout_msg']="You have Successfully Logged out.";
		header("Location:index.php");
?>