<?php 
$con=mysql_connect("localhost","root","");
if(!$con){
	die("Sorry! Connection is broken");
}
mysql_select_db("publish_news",$con);
?>