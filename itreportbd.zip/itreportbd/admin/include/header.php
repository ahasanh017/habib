<?php
session_start();
$user_id=$_SESSION['id'];
$user_status=$_SESSION['uname'];
$user_msg=$_SESSION['logged_msg'];
$i=1;

if($user_id==$i<100)

{
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Welcome To Itreportbd</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
	<style type="text/css">
			body{
				background-image:url(images/texture.jpg);
			}
		</style>
</head>
<body>
<div class="container">
	<div class="row">
	<div class="col-md-4 ">
		<div class="form-group btn btn-info text-left">
		<h3><span class="btn-primary">IT Report Bd</span></h3>
		<div class="form-control">
		<label><a href="home.php" id="">Dashboard</a></label>
		</div>
		<div class="form-control">
		<label><a href="#" id="">View All Catagori</a></label>
		</div>
		<div class="form-control">
		<label><a href="#" id="">Create New Catagori</a></label>
		</div>
		
		<h3><span class="btn-primary">News</span></h3>
		<div class="form-control">
		<label><a href="view_product.php" id="">View All News</a></label>
		</div>
		<div class="form-control">
		<label><a href="insert_product.php" id="">INSERT a News </a></label>
		</div>
		<h2>Slider</h2>
		<div class="form-control">
		<label><a href="#" id="" >View slider</a></label>
		</div>
		<div class="form-control">
		<label><a href="insert_slider.php" id="" >Insert slider Image</a></label>
		</div>
		<h2>Usere</h2>
		<div class="form-control">
		<label><a href="view_user.php" id="" >View All User</a></label>
		</div>
		<div class="form-control">
		<label><a href="create_user.php" id="" >Create New User</a></label>
		</div>
		<div class="form-control">
		<label><a href="logout.php" id="" >Logout</a></label>
		</div>
	</div>
	</div>
	<?php
}
else
{
	$_SESSION['error_msg']="You are not Registered.<br>Please Contact With Administrator";
	header("Location:index.php");
}
?>