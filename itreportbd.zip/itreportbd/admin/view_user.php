<?php include("include/header.php"); ?>
<div class="col-md-8">
<font color="yellow">
	<table align="center" width="90%" border="1" style="margin-top:70px;">
		<tr>
		<td><b>User name</b></td>
		<td><b>Password</b></td>
		<td><b>Email</b></td>
		</tr>
		<?php 

include("include/db_connect.php");
	$result = mysql_query("SELECT * FROM user");
	while( $row = mysql_fetch_array($result) )
                {
				?>
				<tr>
		<td><?php echo $row['uname'].""; ?></td>
		<td><?php echo $row['password'].""; ?></td>
		<td><?php echo $row['email'].""; ?></td>
		</tr>
		<?php
				}
				mysql_close($con);
				?>
		
	</table>
	</font>
</div>
<?php include("include/footer.php"); ?>